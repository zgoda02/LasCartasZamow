
import Database from 'better-sqlite3'
const db = new Database(process.env.DB_FILE || 'app.sqlite')

// seed items to match the demo
const DEFAULTS = [
  // category, id, name, unit, priceH, priceS
  ['klamoty','vintek','Vintek','',300000,270000],
  ['klamoty','pistol','Pistolet','',75000,50000],
  ['klamoty','taser','Taser','',120000,100000],
  ['dodatki','kajdanki','Kajdanki','',150000,125000],
  ['dodatki','kamizelka','Kamizelka','',250000,200000],
  ['dodatki','latarka','Latarka','',15000,10000],
  ['ammo','ammo9','Ammo 9mm','szt.',1500,1250],
  ['ammo','ammo556','Ammo 5.56','szt.',2500,2200],
]

db.exec(`
CREATE TABLE IF NOT EXISTS items(
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  unit TEXT DEFAULT '',
  category TEXT NOT NULL,
  priceH INTEGER NOT NULL,
  priceS INTEGER NOT NULL
);
`)

const ins = db.prepare('INSERT OR REPLACE INTO items(id,name,unit,category,priceH,priceS) VALUES(?,?,?,?,?,?)')
const trx = db.transaction(()=>{
  DEFAULTS.forEach(([cat,id,name,unit,ph,ps])=> ins.run(id,name,unit,cat,ph,ps))
})
trx()
console.log('Database seeded with default items.')
